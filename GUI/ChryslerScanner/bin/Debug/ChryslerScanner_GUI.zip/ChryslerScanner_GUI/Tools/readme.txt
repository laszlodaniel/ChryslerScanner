Chrysler CCD/SCI Scanner (v1) manual firmware update:
1. Disconnect from the scanner and close the GUI. Keep USB cable connected.
2. Edit update_v1.bat file by replacing "COMX" with your actual COM-port, example: COM3 or COM15.
3. Download latest flash file from https://raw.githubusercontent.com/laszlodaniel/ChryslerScanner/master/Arduino/ChryslerCCDSCIScanner/ChryslerCCDSCIScanner.ino.mega.hex
4. Place flash file into this folder and execute update_v1.bat.

Chrysler Scanner (v2) manual firmware update:
1. Disconnect from the scanner and close the GUI. Keep USB cable connected.
2. Edit update_v2.bat file by replacing "COMX" with your actual COM-port, example: COM3 or COM15.
3. Download latest flash file from https://raw.githubusercontent.com/laszlodaniel/ChryslerScanner/master/PlatformIO/ChryslerScanner/src/ChryslerScanner.bin
4. Place flash file into this folder and execute update_v2.bat.

Automatic firmware update (internet connection necessary):
1. Run GUI.
2. Connect to the scanner.
3. Select "Tools / Update".
4. Latest GUI update is downloaded as a zip-file to the Update folder, overwrite ChryslerScanner.exe manually.
5. Scanner firmware (v1/v2) is updated automatically.